﻿using Microsoft.Toolkit.Services.MicrosoftGraph;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsTestApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // values to connect to Microsoft Graph
            graphLoginComponent1.ClientId = "f652df2c-f3f3-43b2-9db9-35af03051d74";
            graphLoginComponent1.Scopes = new string[] { "User.Read" };
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            
            var msGraphService = await graphLoginComponent1.LoginAsync();

            //update the user's display fields
            var graphUser = await msGraphService.User.GetProfileAsync();
            label1.Text = graphUser.DisplayName;
            label2.Text = graphUser.JobTitle;

            // update the image
            using (Stream photoStream = await msGraphService.GraphProvider.Me.Photo.Content.Request().GetAsync())
            {
                if (photoStream != null)
                {
                    pictureBox1.Image = Image.FromStream(photoStream);
                }
            }
        }
    }
}
