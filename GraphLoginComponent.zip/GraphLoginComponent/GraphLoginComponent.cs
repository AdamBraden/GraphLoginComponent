﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Toolkit.Services.MicrosoftGraph;

namespace GraphLoginComponent
{
    public partial class GraphLoginComponent : Component
    {
        private string clientId;
        private string[] scopes;

        public GraphLoginComponent()
        {
            InitializeComponent();
        }

        public GraphLoginComponent(IContainer container)
        {
            container.Add(this);

            InitializeComponent();
        }
        public string ClientId { get => clientId; set => clientId = value; }
        public string[] Scopes { get => scopes; set => scopes = value; }

        /// <summary>
        /// LoginAsync provides entrypoint into the MicrosoftGraphService LoginAsync
        /// </summary>
        /// <returns>A MicrosoftGraphService reference</returns>
        public async Task<MicrosoftGraphService> LoginAsync()
        {
            // check inputs
            if (string.IsNullOrEmpty(clientId))
            {
                //error
                return null;
            }

            if (!MicrosoftGraphService.Instance.Initialize(clientId,delegatedPermissionScopes: Scopes))
            {
                return null;
            }

            // login and return
            try
            {
                await MicrosoftGraphService.Instance.LoginAsync();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                return null;
            }

            // Return MicrosoftGraphService or GraphProvider (SDK's GraphServiceClient)?
            // return MicrosoftGraphService.Instance.GraphProvider;
            return MicrosoftGraphService.Instance;
    
        }
    }
}
